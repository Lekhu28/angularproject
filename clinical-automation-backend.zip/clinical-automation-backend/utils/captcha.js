const captchas = new Map();

function generateCaptcha(sessionId) {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let captcha = '';
  for (let i = 0; i < 5; i++) {
    captcha += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  captchas.set(sessionId, captcha);
  return captcha;
}

function verifyCaptcha(sessionId, input) {
  const validCaptcha = captchas.get(sessionId);
  if (validCaptcha && validCaptcha === input) {
    captchas.delete(sessionId); 
    return true;
  }
  return false;
}

module.exports = {
  generateCaptcha,
  verifyCaptcha
};
