const Medicine = require('../models/Medicine');


exports.addMedicine = async (req, res) => {
  try {
    const { name, price, taxPercent } = req.body;

   
    const tax = (price * taxPercent) / 100;
    const discount = (price + tax) * 0.10;
    const finalPrice = price + tax - discount;

    const medicine = new Medicine({
      name,
      price,
      taxPercent,
      discountPercent: 10,
      finalPrice,
    });

    await medicine.save();
    res.status(201).json(medicine);
  } catch (err) {
    console.error('Error adding medicine:', err);
    res.status(500).json({ message: 'Server error' });
  }
};


exports.getMedicines = async (req, res) => {
  try {
    const medicines = await Medicine.find();
    res.json(medicines);
  } catch (err) {
    console.error('Error fetching medicines:', err);
    res.status(500).json({ message: 'Server error' });
  }
};


exports.getMedicineById = async (req, res) => {
  try {
    const medicine = await Medicine.findById(req.params.id);
    if (!medicine) {
      return res.status(404).json({ message: 'Medicine not found' });
    }
    res.json(medicine);
  } catch (err) {
    console.error('Error getting medicine:', err);
    res.status(500).json({ message: 'Server error' });
  }
};


exports.updateMedicine = async (req, res) => {
  try {
    const { name, price, taxPercent } = req.body;

    const tax = (price * taxPercent) / 100;
    const discount = (price + tax) * 0.10;
    const finalPrice = price + tax - discount;

    const updatedMedicine = await Medicine.findByIdAndUpdate(
      req.params.id,
      {
        name,
        price,
        taxPercent,
        discountPercent: 10,
        finalPrice,
      },
      { new: true }
    );

    if (!updatedMedicine) {
      return res.status(404).json({ message: 'Medicine not found' });
    }

    res.json(updatedMedicine);
  } catch (err) {
    console.error('Error updating medicine:', err);
    res.status(500).json({ message: 'Server error' });
  }
};


exports.deleteMedicine = async (req, res) => {
  try {
    const medicine = await Medicine.findByIdAndDelete(req.params.id);
    if (!medicine) {
      return res.status(404).json({ message: 'Medicine not found' });
    }
    res.json({ message: 'Medicine deleted' });
  } catch (err) {
    console.error('Error deleting medicine:', err);
    res.status(500).json({ message: 'Server error' });
  }
};
