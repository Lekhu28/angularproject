const Doctor = require('../models/Dr');
const Patient = require('../models/Patient');
const Pharmacist = require('../models/Pharmacist');
const Executive = require('../models/Executive');

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const { validationResult } = require('express-validator');
const { verifyCaptcha } = require('../utils/captcha');  

exports.register = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ errors: errors.array() });

  const { name, email, password, role, contact, dob,captcha, experience, availableTimings, specialization, sessionId } = req.body;

 
  if (!verifyCaptcha(sessionId,captcha)) {
    return res.status(400).json({ message: 'Invalid captcha' });
  }

  try {
    let user = await User.findOne({ email });
    if (user)
      return res.status(400).json({ message: 'Already exists' });

    const hPassword = await bcrypt.hash(password, 10);

    user = new User({ name, email, password: hPassword, role, contact, dob });
    const savedUser = await user.save();

   if (role === 'patient') {
      console.log('Saving to patient DB...');
      const patient = new Patient({ name, email, role, contact, dob });
      const savedPatient = await patient.save();
      console.log('Patient saved:', savedPatient);
    } else if (role === 'doctor') {
      console.log('Saving to doctor DB...');
      const doctor = new Doctor({ name, email, role, contact, experience });
      const savedDoctor = await doctor.save();
      console.log('Doctor saved:', savedDoctor);
    } else if (role === 'pharmacist') {
      console.log('Saving to pharmacist DB...');
      const pharmacist = new Pharmacist({ name, email, role, contact });
      const savedPharmacist = await pharmacist.save();
      console.log('Pharmacist saved:', savedPharmacist);
    } else if (role === 'executive') {
      console.log('Saving to executive DB...');
      const executive = new Executive({ name, email, role, contact });
      const savedExecutive = await executive.save();
      console.log('Executive saved:', savedExecutive);
    }

    res.status(201).json({ message: 'Registered successfully' });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};

exports.login = async (req, res) => {
  const { email, password, captcha, sessionId } = req.body;

 
  if (!verifyCaptcha(sessionId, captcha)) {
    return res.status(400).json({ message: 'Invalid captcha' });
  }

  try {
    const user = await User.findOne({ email });
    if (!user)
      return res.status(400).json({ message: 'Invalid user' });

    const isMatch = await bcrypt.compare(password, user.password);
    if (!isMatch)
      return res.status(400).json({ message: 'Invalid user' });

    const payload = {
      user: {
        id: user.id,
        role: user.role
      }
    };

    const token = jwt.sign(payload, process.env.JWT_SECRET, {
      expiresIn: '7d'
    });

    res.json({ token });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};

exports.getProfile = async (req, res) => {
  try {
    const user = await User.findById(req.user.id).select('-password');
    res.json(user);
  } catch (err) {
    console.error(err.message);
    res.status(500).send('Server Error');
  }
};
