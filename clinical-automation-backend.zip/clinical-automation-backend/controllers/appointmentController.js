const Appointment = require('../models/Appointment');
const { validationResult } = require('express-validator');

exports.bookAppointment = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty())
    return res.status(400).json({ errors: errors.array() });

  const { doctor, date, time } = req.body;

  try {
    const appointment = new Appointment({
      patient: req.user.id,
      doctor,
      date,
      time
    });

    await appointment.save();
    res.status(201).json({ message: 'Appointment booked', appointment });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};


exports.approveAppointment = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id);
    if (!appointment)
      return res.status(404).json({ message: 'Appointment not found' });

    appointment.status = 'Approved';
    await appointment.save();

    res.json({ message: 'Appointment approved', appointment });
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};


exports.getMyAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find({ patient: req.user.id })
      .populate('doctor', 'name specialization')
      .sort({ date: -1 });

    res.json(appointments);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};


exports.getAllAppointments = async (req, res) => {
  try {
    const appointments = await Appointment.find()
      .populate('patient', 'name')
      .populate('doctor', 'name');

    res.json(appointments);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};


exports.searchAppointments = async (req, res) => {
  const { keyword } = req.query;

  try {
    const appointments = await Appointment.find()
      .populate({
        path: 'patient',
        match: {
          $or: [
            { name: { $regex: keyword, $options: 'i' } },
            { _id: keyword }
          ]
        }
      })
      .populate('doctor', 'name');

    const filtered = appointments.filter(a => a.patient !== null);
    res.json(filtered);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server Error');
  }
};
