const Query = require('../models/Query');
const Appointment = require('../models/Appointment');
const Doctor = require('../models/Dr');
const mongoose = require('mongoose');


exports.sendQuery = async (req, res) => {
  const { doctorId, appointmentId, question } = req.body;

  try {
    const appointment = await Appointment.findById(appointmentId);
    if (!appointment || appointment.patient.toString() !== req.user.id || appointment.doctor.toString() !== doctorId) {
      return res.status(400).json({ message: 'Invalid appointment' });
    }

    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const queryCount = await Query.countDocuments({
      patient: req.user.id,
      doctor: doctorId,
      appointment: appointmentId,
      createdAt: { $gte: oneWeekAgo }
    });

    if (queryCount >= 2) {
      return res.status(403).json({ message: 'Maximum 2 queries allowed within one week of visit' });
    }

    const query = new Query({
      patient: req.user.id,
      doctor: doctorId,
      appointment: appointmentId,
      question
    });

    await query.save();
    res.status(201).json({ message: 'Query submitted', query });

  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};


exports.getMyQueries = async (req, res) => {
  try {
    const queries = await Query.find({ patient: req.user.id })
      .populate('doctor', 'name specialization')
      .populate('appointment', 'date');
    res.json(queries);
  } catch (err) {
    console.error(err);
    res.status(500).send('Server error');
  }
};
