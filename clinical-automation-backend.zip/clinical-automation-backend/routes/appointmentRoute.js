const express = require('express');
const { check } = require('express-validator');
const router = express.Router();

const appointmentController = require('../controllers/appointmentController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');


router.post(
  '/book',
  authMiddleware,
  [
    check('doctor', 'Doctor ID is required').notEmpty(),
    check('date', 'Date is required').notEmpty(),
    check('time', 'Time is required').notEmpty()
  ],
  appointmentController.bookAppointment
);


router.put(
  '/approve/:id',
  authMiddleware,
  roleMiddleware(['front-office']),
  appointmentController.approveAppointment
);


router.get('/my', authMiddleware, appointmentController.getMyAppointments);

router.get('/all', authMiddleware, roleMiddleware(['front-office', 'admin']), appointmentController.getAllAppointments);

router.get('/search', authMiddleware, roleMiddleware(['front-office', 'admin']), appointmentController.searchAppointments);

module.exports = router;
