const express = require('express');
const router = express.Router();
const medicineController = require('../controllers/medicineController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');


router.post(
  '/',
  authMiddleware,
  roleMiddleware(['pharmacist']),
  medicineController.addMedicine
);


router.get('/', medicineController.getMedicines);


router.get('/:id', medicineController.getMedicineById);

router.put(
  '/:id',
  authMiddleware,
  roleMiddleware(['pharmacist']),
  medicineController.updateMedicine
);


router.delete(
  '/:id',
  authMiddleware,
  roleMiddleware(['pharmacist']),
  medicineController.deleteMedicine
);

module.exports = router;
