const express = require('express');
const { check } = require('express-validator');
const router = express.Router();

const queryController = require('../controllers/queryController');
const authMiddleware = require('../middleware/authMiddleware');
const roleMiddleware = require('../middleware/roleMiddleware');


router.post(
  '/',
  authMiddleware,
  roleMiddleware(['patient']),
  [
    check('doctorId', 'Doctor ID is required').notEmpty(),
    check('appointmentId', 'Appointment ID is required').notEmpty(),
    check('question', 'Question is required').notEmpty()
  ],
  queryController.sendQuery
);


router.get(
  '/my-queries',
  authMiddleware,
  roleMiddleware(['patient']),
  queryController.getMyQueries
);

module.exports = router;
