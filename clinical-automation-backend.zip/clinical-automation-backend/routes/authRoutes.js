const express = require('express');
const { check } = require('express-validator');
const router = express.Router();

const authController = require('../controllers/authController');
const authMiddleware = require('../middleware/authMiddleware');
const { generateCaptcha } = require('../utils/captcha');

router.post(
  '/register',
  [
    check('name', 'Name is required').notEmpty(),
    check('email', 'Valid email is required').isEmail(),
    check('password', 'Password must be 7 to 10 characters long').isLength({ min: 7, max: 10 }),
    check('role', 'Role is required').notEmpty(),
    check('contact', 'Role is required').notEmpty(),
    check('dob', 'Role is required').notEmpty(),
    check('captcha', 'Captcha is required').notEmpty()
    
  ],
  authController.register
);

router.post(
  '/login',
  [
    check('email', 'Valid email is required').isEmail(),
    check('password', 'Password is required').notEmpty(),
    check('captcha', 'Captcha is required').notEmpty(),
    check('sessionId', 'Session ID is required').notEmpty()
  ],
  authController.login
);

router.get('/profile', authMiddleware, authController.getProfile);

router.get('/get-captcha/:sessionId', (req, res) => {
  const captcha = generateCaptcha(req.params.sessionId);
  res.json({ captcha });
});

module.exports = router;
