const mongoose = require('mongoose');

const querySchema = new mongoose.Schema({
  patientId: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  doctorId: { type: mongoose.Schema.Types.ObjectId, ref: 'Doctor', required: true },
  message: { type: String, required: true },
  response: { type: String },
  dateOfVisit: { type: Date, required: true },
  createdAt: { type: Date, default: Date.now },
  status: {
    type: String,
    enum: ['open', 'close'],
    default: 'open'
  }
});

module.exports = mongoose.model('Query', querySchema);
