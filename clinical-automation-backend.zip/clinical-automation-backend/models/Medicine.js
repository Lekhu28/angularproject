const mongoose = require('mongoose');

const medicineSchema = new mongoose.Schema({
  name: { type: String, required: true },
  brand: String,
  price: { type: Number, required: true },
  tax: { type: Number, default: 0 },
  discount: { type: Number, default: 0 },
  stock: { type: Number, default: 0 },
  description: String
});


medicineSchema.virtual('finalPrice').get(function () {
  return (this.price + this.tax) - this.discount;
});

module.exports = mongoose.model('Medicine', medicineSchema);
