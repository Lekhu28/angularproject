const mongoose = require('mongoose');

const doctorSchema = new mongoose.Schema({
  userId: {type: mongoose.Schema.Types.ObjectId, ref:'User'},
  name: { type: String, required: true },
  specialization: { type: String, required: true },
  experience: {type: String, required: true},
  availableTimings: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  phone: { type: String },
});

module.exports = mongoose.model('Doctor', doctorSchema);
